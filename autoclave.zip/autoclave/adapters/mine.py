import time
import random
from adapter import Solver, cost_of

class MySolver(Solver):
    def solve(self, instance, submit_candidate):
        start_time = time.time()
        
        # Scale time budget dynamically based on instance size
        # Larger instances get closer to the full 4.8s buffer
        if instance.size >= 70:
            time_budget = 4.85
        elif instance.size >= 40:
            time_budget = 4.7
        else:
            time_budget = 4.5
            
        # 1. Generate diverse initial starting strategies
        orders = [
            sorted(range(instance.size), key=lambda b: (instance.fam[b], instance.due[b])),
            sorted(range(instance.size), key=lambda b: (instance.release[b], instance.due[b])),
            sorted(range(instance.size), key=lambda b: (instance.due[b], b)),
            sorted(range(instance.size), key=lambda b: (instance.weight[b], instance.due[b]))
        ]
        
        best_order = orders[0]
        best_cost = cost_of(instance, best_order)
        submit_candidate({"order": best_order})
        
        for initial_order in orders[1:]:
            cost = cost_of(instance, initial_order)
            if cost < best_cost:
                best_cost = cost
                best_order = initial_order
                submit_candidate({"order": best_order})
                
        current_order = list(best_order)
        current_cost = best_cost
        
        # 2. Local Search with Relocate and Swap neighborhoods
        while (time.time() - start_time) < time_budget:
            improved = False
            
            # Sample subset of indices for large instances to speed up exploration
            indices = list(range(instance.size))
            if instance.size > 50:
                random.shuffle(indices)
                indices = indices[:min(instance.size, 45)]
                
            for i in indices:
                if (time.time() - start_time) >= time_budget:
                    break
                for j in indices:
                    if i == j:
                        continue
                        
                    # Try Relocate (Shift) move
                    candidate_order = list(current_order)
                    item = candidate_order.pop(i)
                    candidate_order.insert(j, item)
                    
                    cost = cost_of(instance, candidate_order)
                    if cost < current_cost:
                        current_cost = cost
                        current_order = candidate_order
                        if current_cost < best_cost:
                            best_cost = current_cost
                            best_order = list(current_order)
                            submit_candidate({"order": best_order})
                        improved = True
                        break
                if improved:
                    break
            
            # If no improvement found in this pass, shuffle slightly to break out of local optima
            if not improved:
                if len(current_order) > 3:
                    idx1, idx2 = random.sample(range(instance.size), 2)
                    current_order[idx1], current_order[idx2] = current_order[idx2], current_order[idx1]
                    current_cost = cost_of(instance, current_order)
                else:
                    break
                    
        return {"order": best_order}